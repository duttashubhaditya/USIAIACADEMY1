CREATE TABLE dbo.mpg_data1
( 
    mpg float NOT NULL, 
    cylinders int NOT NULL, 
    displacement float NOT NULL, 
    horsepower int NOT NULL, 
    weight int NOT NULL, 
    acceleration float NOT NULL, 
    model_year int NOT NULL, 
    origin int NOT NULL, 
    name varchar(50), 
) 
GO